import express from "express";

import {
  updateUserRole,
  listUsers,
  deleteUser,
  disableUser,
  enableUser,
  filterUsersByBody,
  adminGetAllNews,
  togglePublishStatus,
} from "../controller/admin.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { authorizeRoles } from "../middleware/role.middleware.js";
const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Admin
 *   description: Admin-only user management APIs
 */

/**
 * @swagger
 * /api/admin/users/{id}/role:
 *   patch:
 *     summary: Update a user's role (Admin only)
 *     description: >
 *       Allows an admin to change a user's role.
 *       Normal users cannot access this endpoint.
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: MongoDB ObjectId of the user
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - role
 *             properties:
 *               role:
 *                 type: string
 *                 enum: [user, editor, admin]
 *                 example: editor
 *     responses:
 *       200:
 *         description: User role updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: User role updated successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                     email:
 *                       type: string
 *                     role:
 *                       type: string
 *       400:
 *         description: Invalid role or self-role modification attempt
 *       401:
 *         description: Unauthorized (not logged in)
 *       403:
 *         description: Forbidden (admin access required)
 *       404:
 *         description: User not found
 */

router.patch(
  "/users/:id/role",
  authenticate,
  authorizeRoles("admin"),
  updateUserRole,
);

/**
 * @swagger
 * /api/admin/users:
 *   get:
 *     summary: List users (Admin only)
 *     description: Returns a list of users. Pagination is optional and applied only if page or limit is provided. Admin can optionally filter users by role.
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           example: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           example: 10
 *       - in: query
 *         name: role
 *         schema:
 *           type: string
 *           enum: [user, editor, admin]
 *     responses:
 *       200:
 *         description: Users fetched successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Users fetched successfully
 *                 pagination:
 *                   type: object
 *                   properties:
 *                     total:
 *                       type: integer
 *                     page:
 *                       type: integer
 *                     limit:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       _id:
 *                         type: string
 *                       name:
 *                         type: string
 *                       email:
 *                         type: string
 *                       role:
 *                         type: string
 *                       createdAt:
 *                         type: string
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden (admin access required)
 */
router.get("/users", authenticate, authorizeRoles("admin"), listUsers);

/**
 * @swagger
 * /api/admin/users/filter:
 *   post:
 *     summary: Filter and search users (Admin only)
 *     description: |
 *       Fetch users using request body filters.
 *       Supports role filtering, search by name/email, and optional pagination.
 *
 *       🔹 Examples:
 *       - All users → `{ }`
 *       - Role filter → `{ "role": "editor" }`
 *       - Search → `{ "search": "rahul" }`
 *       - Pagination → `{ "page": 1, "limit": 10 }`
 *       - Role + search + pagination →
 *         `{ "role": "editor", "search": "rahul", "page": 1, "limit": 5 }`
 *
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               role:
 *                 type: string
 *                 enum: [user, editor, admin]
 *                 example: editor
 *               search:
 *                 type: string
 *                 example: rahul
 *                 description: Search by name or email
 *               page:
 *                 type: integer
 *                 example: 1
 *               limit:
 *                 type: integer
 *                 example: 10
 *     responses:
 *       200:
 *         description: Users fetched successfully
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden (Admin only)
 */

router.post(
  "/users/filter",
  authenticate,
  authorizeRoles("admin"),
  filterUsersByBody,
);

/**
 * Admin-only: Delete user
 */

/**
 * @swagger
 * /api/admin/users/{id}:
 *   delete:
 *     summary: Delete a user (Admin only)
 *     description: >
 *       Deletes a user by ID.
 *       Admin cannot delete their own account and
 *       the system must always have at least one admin.
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: MongoDB ObjectId of the user
 *     responses:
 *       200:
 *         description: User deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: User deleted successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                     email:
 *                       type: string
 *                     role:
 *                       type: string
 *       400:
 *         description: Self-delete attempt or last admin protection
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden (admin access required)
 *       404:
 *         description: User not found
 */

router.delete("/users/:id", authenticate, authorizeRoles("admin"), deleteUser);

/**
 * @swagger
 * /api/admin/users/{id}/disable:
 *   patch:
 *     summary: Disable a user (Admin only)
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User disabled successfully
 *       400:
 *         description: User already disabled or self-disable attempt
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: User not found
 */
router.patch(
  "/users/:id/disable",
  authenticate,
  authorizeRoles("admin"),
  disableUser,
);

/**
 * @swagger
 * /api/admin/users/{id}/enable:
 *   patch:
 *     summary: Enable a user (Admin only)
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: User enabled successfully
 *       400:
 *         description: User already active
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden
 *       404:
 *         description: User not found
 */

router.patch(
  "/users/:id/enable",
  authenticate,
  authorizeRoles("admin"),
  enableUser,
);

/**
 * @swagger
 * /api/admin/news:
 *   get:
 *     summary: Admin - Get all news (published and unpublished)
 *     description: |
 *       Returns all news articles including drafts.
 *       Supports filtering by category, publish status, and pagination.
 *
 *       🔐 Admin only.
 *
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *
 *     parameters:
 *       - in: query
 *         name: category
 *         schema:
 *           type: string
 *           enum: [politics, sports, technology, business, health, entertainment]
 *         description: Filter by category
 *
 *       - in: query
 *         name: isPublished
 *         schema:
 *           type: boolean
 *         description: true = published, false = drafts
 *
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           example: 1
 *
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           example: 10
 *
 *     responses:
 *       200:
 *         description: News list returned
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/News'
 *                 pagination:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                     limit:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 *                     totalResults:
 *                       type: integer
 *
 *       401:
 *         description: Unauthorized
 *
 *       403:
 *         description: Forbidden (Admin only)
 */

router.get("/news", authenticate, authorizeRoles("admin"), adminGetAllNews);

/**
 * @swagger
 * /api/admin/news/{id}/publish:
 *   patch:
 *     summary: Admin - Publish or unpublish a news article
 *     description: |
 *       Updates publish status of a news article.
 *
 *       🔐 Admin only.
 *
 *     tags: [Admin]
 *     security:
 *       - cookieAuth: []
 *       - bearerAuth: []
 *
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: News ID
 *
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - isPublished
 *             properties:
 *               isPublished:
 *                 type: boolean
 *                 example: true
 *
 *     responses:
 *       200:
 *         description: Publish status updated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: News published successfully
 *                 data:
 *                   $ref: '#/components/schemas/News'
 *
 *       401:
 *         description: Unauthorized
 *
 *       403:
 *         description: Forbidden (Admin only)
 *
 *       404:
 *         description: News not found
 */

router.patch(
  "/news/:id/publish",
  authenticate,
  authorizeRoles("admin"),
  togglePublishStatus,
);

export default router;
